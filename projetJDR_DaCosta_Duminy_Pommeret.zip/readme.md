Etudiants du groupe :
	Lucas Da Costa DACL28089709
	Guillaume Duminy DUMG28129601
	Jean-Baptiste Pommeret POMJ13019703

Pour la BD

1) Creer une base de donnée "jdr" vide.

2) Importer les tables et les données à l'aide du script "jdr.sql" dans la base de donnée jdr


Liste des utilisateurs existant :

Bob
	login :		bob@gmail.com
	password :	superman

amesk
	login :		azerty@gmail.com
	password :	azerty

Alice
	login :		alice@gmail.com
	password :	alice