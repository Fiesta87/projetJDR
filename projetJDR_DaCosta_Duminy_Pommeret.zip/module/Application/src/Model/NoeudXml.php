<?php
/**
 * Created by PhpStorm.
 * User: Lucas
 * Date: 26/04/2018
 * Time: 21:13
 */

namespace Application\Model;


class NoeudXml
{
    public $name;
    public $value;

    public  $attribute=array();

    public $child=array();

    public function __construct()
    {

    }
}

